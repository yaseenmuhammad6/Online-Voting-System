<?php 
    function CHECKWINNAME($con,$na,$election,$votes)
    {
        $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$na' && `votes`='$votes'") or die('Error');
            while($row1 = mysqli_fetch_array($result1)) {
                         $winingcandidate= $row1["name"];
             }
             
        if (isset($winingcandidate)) {
            $sql1 = "INSERT INTO `result`(`constituency`, `won by`, `election`) VALUES
            ('$na','$winingcandidate','$election')";
        
            if ($con->query($sql1) === TRUE) { echo ' ';} 
            else {   echo "Error: " . $sql1 . "<br>" . $con->error; }

            return $winingcandidate;
        }
        else {
            return "NO CANDIDATE";
        }
    }

    function CHECKWINPARTY($con,$na,$election,$votes)
    {
        $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$na' && `votes`='$votes'") or die('Error');
            while($row1 = mysqli_fetch_array($result1)) {
                        $winingcandidate= $row1["name"];
                         $winingcandidateparty= $row1["party"];
             }
             
        if (isset($winingcandidate)) {
            $sql4="UPDATE `nationalassembly` SET `wonby`='$winingcandidate',`party`='$winingcandidateparty',`election`='$election' WHERE `constituency`='$na'";
            if ($con->query($sql4) === TRUE) 
            { echo " ";} else  {   echo "Error: " . $sql4 . "<br>" . $con->error;}

            return $winingcandidateparty;
        }
        else {
            return "NO CANDIDATE";
        }
    }

    function CHECKWINPARTYPROVINCE($con,$na,$election,$votes)
    {
        $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$na' && `votes`='$votes'") or die('Error');
            while($row1 = mysqli_fetch_array($result1)) {
                        $winingcandidate= $row1["name"];
                         $winingcandidateparty= $row1["party"];
             }
             
        if (isset($winingcandidate)) {
            $sql4="UPDATE `provincialassemblies` SET `wonby`='$winingcandidate',`party`='$winingcandidateparty',`election`='$election' WHERE `constituency`='$na'";
            if ($con->query($sql4) === TRUE) 
            { echo " ";} else  {   echo "Error: " . $sql4 . "<br>" . $con->error;}

            return $winingcandidateparty;
        }
        else {
            return "NO CANDIDATE";
        }
    }
    
    function CHECKWINPARTYsenate($con,$na,$election,$votes)
    {
        $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$na' && `votes`='$votes'") or die('Error');
            while($row1 = mysqli_fetch_array($result1)) {
                        $winingcandidate= $row1["name"];
                         $winingcandidateparty= $row1["party"];
             }
             
        if (isset($winingcandidate)) {
            $sql4="UPDATE `senate` SET `wonby`='$winingcandidate',`party`='$winingcandidateparty',`election`='$election' WHERE `constituency`='$na'";
            if ($con->query($sql4) === TRUE) 
            { echo " ";} else  {   echo "Error: " . $sql4 . "<br>" . $con->error;}

            return $winingcandidateparty;
        }
        else {
            return "NO CANDIDATE";
        }
    }
    function CHECKWINNAMEPRE($con,$na,$election,$votes)
    {
        $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$na' && `votes`='$votes'") or die('Error');
            while($row1 = mysqli_fetch_array($result1)) {
                         $winingcandidate= $row1["name"];
             }
             
        if (isset($winingcandidate)) {
            $sql1 = "INSERT INTO `results`(`election name`, `election type`, `won by`) VALUES
            ('$election','President','$winingcandidate')";
            if ($con->query($sql1) === TRUE) { echo ' ';} 
            else {   echo "Error: " . $sql1 . "<br>" . $con->error; }
            return $winingcandidate;
        }
        else {
            return "NO CANDIDATE";
        }
    }

    function CHECKWINPARTYpresident($con,$na,$election,$votes)
    {
        $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$na' && `votes`='$votes'") or die('Error');
            while($row1 = mysqli_fetch_array($result1)) {
                        $winingcandidate= $row1["name"];
                         $winingcandidateparty= $row1["party"];
             }
             
        if (isset($winingcandidate)) {

            return $winingcandidate;
        }
        else {
            return "NO CANDIDATE";
        }
    }
    function nationalassemblyresults($con,$na,$election){
       echo '<div class="container-fluid">
                <div class="shadow p-3 mb-5 bg-white rounded">
                <div class="row">
                <div class="col">

                </div>
                </div>
                </div>
            <table class="table" style="text-align: center;">
            <thead>
            <tr>
            <th>CONSITUIENCY</th>
            <th>WINING CANDIDATE NAME</th>
            <th>WINING CANDIDATE PARTY</th>
            <th>TOTAL VOTES OF WINING CANDIDATE</th>
            </tr>
            ';
            $votesgain=0;
            for ($i=1; $i <=$na ; $i++) { 
                
                $NAnum="NA$i";
                $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$NAnum'") or die('Error');
            while($row1 = mysqli_fetch_array($result1)) {
                    if ($row1["votes"]>$votesgain) {
                        //  $winingcandidate= $row1["name"];
                        //  $winingcandidateparty =$row1["party"];
                        $votesgain =$row1["votes"];
                    }
                    
             }
                echo'<tr>
                <td>'.$NAnum.'</td>
                <td>'.$winnername=CHECKWINNAME($con,$NAnum,$election,$votesgain).'</td>
                <td>'.$winerparty=CHECKWINPARTY($con,$NAnum,$election,$votesgain).'</td>
                <td>'.$votesgain.'</td>
                </tr>';
                
                $votesgain=0;
            }
         echo'    
            </thead>
            </table>
       </div>';
    }
   function LocationChecker($location)
   {
       if ($location="Punjab") {
           return "PP";
       }
       elseif ($location="Sindh") {
        return "PS";
    }
    elseif ($location="KPK") {
        return "PK";
    }
    elseif ($location="Baluchistan") {
        return "PB";
    }
    elseif ($location="Gilgit Baltistan") {
        return "GB";
    }
    elseif ($location="Azad Kashmir") {
        return "AJK";
    }
   }
    function provinicialassemblyresults($con,$location,$election){
        echo '<div class="container-fluid">
                 <div class="shadow p-3 mb-5 bg-white rounded">
                 <div class="row">
                 <div class="col">
 
                 </div>
                 </div>
                 </div>
             <table class="table" style="text-align: center;">
             <thead>
             <tr>
             <th>CONSITUIENCY</th>
             <th>WINING CANDIDATE NAME</th>
             <th>WINING CANDIDATE PARTY</th>
             <th>TOTAL VOTES OF WINING CANDIDATE</th>
             </tr>
             ';
             $votesgain=0;
             for ($i=1; $i <=$na ; $i++) { 
                 $PC=LocationChecker($location);
                 $NAnum="$PC$i";
                 $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$NAnum'") or die('Error');
             while($row1 = mysqli_fetch_array($result1)) {
                     if ($row1["votes"]>$votesgain) {
                         //  $winingcandidate= $row1["name"];
                         //  $winingcandidateparty =$row1["party"];
                         $votesgain =$row1["votes"];
                     }
                     
              }
                 echo'<tr>
                 <td>'.$NAnum.'</td>
                 <td>'.$winnername=CHECKWINNAME($con,$NAnum,$election,$votesgain).'</td>
                 <td>'.$winerparty=CHECKWINPARTYPROVINCE($con,$NAnum,$election,$votesgain).'</td>
                 <td>'.$votesgain.'</td>
                 </tr>';
                 
                 $votesgain=0;
             }
          echo'    
             </thead>
             </table>
        </div>';
     }
     function senateresults($con,$senate,$election){
        echo '<div class="container-fluid">
                 <div class="shadow p-3 mb-5 bg-white rounded">
                 <div class="row">
                 <div class="col">
 
                 </div>
                 </div>
                 </div>
             <table class="table" style="text-align: center;">
             <thead>
             <tr>
             <th>CONSITUIENCY</th>
             <th>WINING CANDIDATE NAME</th>
             <th>WINING CANDIDATE PARTY</th>
             <th>TOTAL VOTES OF WINING CANDIDATE</th>
             </tr>
             ';
             $votesgain=0;
             for ($i=1; $i <=$senate ; $i++) { 
                 
                 $NAnum="SENATE-$i";
                 $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$NAnum'") or die('Error');
             while($row1 = mysqli_fetch_array($result1)) {
                     if ($row1["votes"]>$votesgain) {
                         //  $winingcandidate= $row1["name"];
                         //  $winingcandidateparty =$row1["party"];
                         $votesgain =$row1["votes"];
                     }
                     
              }
                 echo'<tr>
                 <td>'.$NAnum.'</td>
                 <td>'.$winnername=CHECKWINNAME($con,$NAnum,$election,$votesgain).'</td>
                 <td>'.$winerparty=CHECKWINPARTYsenate($con,$NAnum,$election,$votesgain).'</td>
                 <td>'.$votesgain.'</td>
                 </tr>';
                 
                 $votesgain=0;
             }
          echo'    
             </thead>
             </table>
        </div>';
     }

     function Presidentresults($con,$election){
        
        echo '<div class="container-fluid">
                 <div class="shadow p-3 mb-5 bg-white rounded">
                 <div class="row">
                 <div class="col">
                    <!--PRESIDENT-->
                 </div>
                 </div>
                 </div>
             <table class="table" style="text-align: center;">
             <thead>
             <tr>
             <th>CONSITUIENCY</th>
             <th>WINING CANDIDATE NAME</th>
             <th>WINING CANDIDATE PARTY</th>
             <th>TOTAL VOTES OF WINING CANDIDATE</th>
             </tr>
             ';
             $votesgain=0;
                 
                 $NAnum="President";
                 $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `election`='$election' && `constituency`='$NAnum'") or die('Error');
             while($row1 = mysqli_fetch_array($result1)) {
                     if ($row1["votes"]>$votesgain) {
                         //  $winingcandidate= $row1["name"];
                         //  $winingcandidateparty =$row1["party"];
                         $votesgain =$row1["votes"];
                     }
                     
              }
                 echo'<tr>
                 <td>'.$NAnum.'</td>
                 <td>'.$winnername=CHECKWINNAMEPRE($con,$NAnum,$election,$votesgain).'</td>
                 <td>'.$winerparty=CHECKWINPARTYpresident($con,$NAnum,$election,$votesgain).'</td>
                 <td>'.$votesgain.'</td>
                 </tr>';
                 
            
          echo'    
             </thead>
             </table>
        </div>';
     }
?>
