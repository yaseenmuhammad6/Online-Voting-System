<?php 
        function President($con,$election){
        
        echo '<table class="table table-hover" >
        <thead>
        <tr>
            <th>CANDIDATE NAME</th>
            <th>POLTICAL AFFILATION</th>
            <th>VOTES</th>
            <th>RESULT</th>
        </tr></thead><tr>
        ';
        $result1 = mysqli_query($con,"SELECT * FROM `election` WHERE `name`='$election'") or die('Error');
        while($row1 = mysqli_fetch_array($result1)) {
                     $votecast= $row1["votecast"];
         }
         $result01 = mysqli_query($con,"SELECT * FROM `results` WHERE `election name`='$election'") or die('Error');
            while($row01 = mysqli_fetch_array($result01)) {
                         $winningcandidate= $row01["won by"];
             }
         $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `constituency`='President' && `election`='$election' ORDER BY `candidate`.`votes` DESC") or die('Error');
        while($row1 = mysqli_fetch_array($result1)) {
                    echo '<tr><td>'.$name=$row1["name"].'</td>';
                    echo '<td>'.$party=$row1["party"].'</td>';
                    echo '<td>'.$votes= $row1["votes"].'</td>';
                    
                    if ($winningcandidate==$row1["name"]) {
                        echo '<td style="color: #16A085;"><b>WON</b></td>';
                    }
                    else {
                        echo '<td style="color: red;">LOST</td>';
                    }
                    echo '</tr>';
         }
        echo'
        </tr>
        </tbody>
    </table>';
    }
    function checkvotes($con,$election,$constituency,$name){
        $result1 = mysqli_query($con,"SELECT * FROM `candidate` WHERE `name`='$name' && `constituency`='$constituency' && `election`='$election'") or die('Error');
        while($row1 = mysqli_fetch_array($result1)) {
                     $vote= $row1["votes"];
         }
         return $vote;
    }
    function OTHERELECTION($con,$election){
        echo '<table class="table table-hover" >
        <thead>
        <tr>
            <th>CONSITUIENCY</th>
            <th>CANDIDATE NAME</th>
            <th>VOTES</th>
            <th>RESULT</th>
        </tr></thead><tr>
        ';
        $result1 = mysqli_query($con,"SELECT * FROM `election` WHERE `name`='$election'") or die('Error');
        while($row1 = mysqli_fetch_array($result1)) {
                     $votecast= $row1["votecast"];
         }
         $result01 = mysqli_query($con,"SELECT * FROM `results` WHERE `election name`='$election'") or die('Error');
            while($row01 = mysqli_fetch_array($result01)) {
                         $winningcandidate= $row01["won by"];
             }
         $result1 = mysqli_query($con,"SELECT * FROM `result` WHERE `election`='$election'") or die('Error');
        while($row1 = mysqli_fetch_array($result1)) {
                    echo '<tr><td>'.$row1["constituency"].'</td>';
                    echo '<td>'.$row1["won by"].'</td>';
                    echo '<td>'.checkvotes($con,$election,$row1["constituency"],$row1["won by"]).'</td>';
                    echo '<td style="color: #16A085;"><b>WON</b></td> </tr>';
         }
        echo'
        </tr>
        </tbody>
    </table>';
    }
?>
