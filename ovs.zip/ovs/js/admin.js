function funi1() {
    document.getElementById("main").innerHTML=`<br><br>
    <center><h1 class="display-1" style="color: #EAECEE;user-select: none;">
          ADMIN DASHBOARD
        </h1></center>`;
}

function addnotifcation() {
    document.getElementById("main").innerHTML=`
    <div class="shadow p-3 mb-5 bg-white rounded"><center><h1>ADD NEW NOTIFICATION</h1>
<br>
      <form action="operation.php?k=1" method="POST">
      
      <div class="input-group mb-3">

            <input type="text" class="form-control" name="noti" placeholder="ADD NEW NOTIFICATION" style="width: 50%;" onkeyup="charcountupdate(this.value)" maxlength="140"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1"><div >NOTIFICATION</div></span></div></div>
            <br>
            <input type="reset" class="btn btn-warning" value="RESET">
            <input type="submit" class="btn btn-success" value="ADD NEW NOTIFICATION">
            <button onclick="funi1()" class="btn btn-danger">CANCEL</button>
            
            </form>
            </center></div>`
            ;
}

function charcountupdate(str){
    var lng = str.length;
	document.getElementById("charcount").innerHTML = lng + ' /140';
}

function addcandidate() {
    document.getElementById("main").innerHTML=` 
    <div class="shadow p-3 mb-5 bg-white rounded"> 
    <form action="candidate.php" method="POST">

    <div class="form-group row">
    <label for="id" class="col-sm-2 col-form-label">ID CARD NUMBER</label>
    <div class="col-sm-10">
      <input type="text" required class="form-control" name="nic" id="id" placeholder="ID CARD NUMBER WITHOUT DASHES" maxlength="13">
     </div>
     </div><br>
     <div class="form-group row">
    <label for="id" class="col-sm-2 col-form-label">NAME</label>
    <div class="col-sm-10">
      <input type="text"  required class="form-control" name="name" id="id" placeholder="FIRST AND LAST NAME" maxlength="50">
     </div>
     </div>
     <br>

     <div class="form-group row">
     <label for="id" class="col-sm-2 col-form-label">FATHERNAME</label>
     <div class="col-sm-10">
       <input type="text" required class="form-control" name="fname" id="id" placeholder="FATHER NAME" maxlength="50">
      </div>
      </div>
      <br>
      <div class="form-group row">
      <label for="id" class="col-sm-2 col-form-label">CONTACT NUMBER</label>
      <div class="col-sm-10">
        <input type="number" required class="form-control" name="contact" id="id" placeholder="CONTACT NUMBER" maxlength="11">
       </div>
       </div>
       <br>
     <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">EDUCATION</label>
        <div class="col-sm-10">
        <select class="form-select" name="qualification" required>
        <option selected disabled>EDUCATION</option>
        <option value="BA/BSC">BA/BSC</option>
        <option value="BS/MSC/MA">BS/MSC/MA</option>
        <option value="MS/MPHIL">MS/MPHIL</option>
        <option value="PHD">PHD</option>
        <option value="DIPLOMA">DIPLOMA</option>
        <option value="SHAHDAT-UL-ALMIA">SHAHDAT-UL-ALMIA</option>
        </select>
        </div>
    </div>
    <br>



    <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">SELECT AN INSTITUTE</label>
        <div class="col-sm-10">
        <select class="form-select" name="Institute" required>
        <option selected disabled>SELECT AN INSTITUTE</option>
        <option value="National Assembly">NATIONAL ASSEMBLY</option>
        <option value="President">President</option>
        <option value="Provincial">Provincial ASSEMBLY</option>
        <option value="District Governments">District Governments</option>
        <option value="Referendum">Referendum</option>
        <option value="Senate">SENATE</option>
        </select>
        </div>
    </div>
    <br>
    <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">SELECT A PROVINCE</label>
        <div class="col-sm-10">
        <select name="province" class="form-select" required>
            <option disabled selected >SELECT A PROVINCE</option>
            <option value="Balochistan">Balochistan</option>
            <option value="Gilgit Baltistan">Gilgit Baltistan</option>
            <option value="Islamabad Capitol Territory">Islamabad Capitol Territory</option>
            <option value="Kashmir">Kashmir</option>
            <option value="Khyber Pakhtunkhwa">Khyber Pakhtunkhwa</option>
            <option value="Panjab">Panjab</option>
            <option value="Sindh">Sindh</option>
            </select>
        </div>
    </div>
    <center><br>
    <input type="reset" class="btn btn-warning" value="RESET">
    <input type="submit" class="btn btn-success" value="ADD NEW CANDIDATE">
            <button onclick="funi1()" class="btn btn-danger">CANCEL</button>
            </center>
    </form></div>`;
}

