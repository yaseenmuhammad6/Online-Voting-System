function party() {
    document.getElementById("main").innerHTML=`
     <div class="row">
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:addparty()"><img src="Images/addparty.png" class="menuimage"></a><br>ADD PARTY</div></div>
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:updateparty()"><img src="Images/updateparty.png" class="menuimage"></a><br>UPDATE PARTY</div></div>
    </div>
    `;
}

function election() {
    document.getElementById("main").innerHTML=`
     <div class="row">
     <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:addelection()"><img src="Images/addelection.png" class="menuimage"></a><br>Create New Election</div></div>
     <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:genrateresult()"><img src="Images/choice.png" class="menuimage"></a><br>Genrate Election Result</div></div>
     <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:symbols()"><img src="Images/symbol.png" class="menuimage"></a><br>ALLOT SYMBOL</div></div>
     </div>
    `;
}
function manageadmin() {
    document.getElementById("main").innerHTML=`
     <div class="row">
     <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:addadmin()"><img src="Images/administrator.png" class="menuimage"></a><br>ADD NEW ADMIN</div></div>
     <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:manageconsituiency()"><img src="Images/location.png" class="menuimage"></a><br>MANAGE CONSITIENCY</div></div>
     <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:removeadmin()"><img src="Images/choice.png" class="menuimage"></a><br>REMOVE ADMIN</div></div>
     </div>`;
}

function addelection() {
    document.getElementById("main").innerHTML=`
     <div class="row">
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:createelection(0)"><img src="Images/capitol.png" class="menuimage"></a><br>National Assembly</div></div>
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:createelection(1)"><img src="Images/president.png" class="menuimage"></a><br>President</div></div>
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:createelection(2)"><img src="Images/capitol.png" class="menuimage"></a><br>Senate</div></div>
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:createelection(3)"><img src="Images/city-hall.png" class="menuimage"></a><br>Provincial</div></div>
    
    

    </div>
    `;
    //<div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:createelection(5)"><img src="Images/debate.png" class="menuimage"></a><br>Refrendum</div></div><div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:createelection(4)"><img src="Images/cityscape.png" class="menuimage"></a><br>District Governments</div></div>
}


function addparty() {
    document.getElementById("main").innerHTML=`
    <div class="row">
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:addparty()"><img src="Images/addparty.png" class="clrimg"></a><br>ADD PARTY</div></div>
    <div class="col"><div class="shadow p-3 mb-5 bg-white rounded"><a href="javascript:updateparty()"><img src="Images/updateparty.png" class="baw"></a><br>UPDATE PARTY</div></div>
    </div>
    <div class="shadow p-3 mb-5 bg-white rounded" style="width: 50%">
    <h5>ADD NEW PARTY</h5>
    <form action="operation.php?k=0" method="POST" enctype="multipart/form-data">
    <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">POLTICAL PARTY  NAME</span></div>
            <input type="text" class="form-control" name="partyname" id="floatingInputValue" placeholder="PARTY NAME" required></div>

            <div class="input-group mb-3">
            <input type="text" class="form-control" name="slogan" id="floatingInputValue" placeholder="MAIN SLOGAN" required><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">MAIN SLOGAN</span></div></div>
            
            <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">FOUNDER NAME</span></div>
            <input type="text" class="form-control" name="founder" id="floatingInputValue" placeholder="FOUNDER NAME" required></div>
            
            <div class="input-group mb-3">
            <input type="text" class="form-control" name="leader" id="floatingInputValue" placeholder="CURRENT LEADER" required><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">CURRENT LEADER</span></div></div>

            <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">LEADER POSITION</span></div>
            <input type="text" class="form-control" name="leaderpostion" id="floatingInputValue" placeholder="LEADER POSITION (President, Chairman, Convener e.t.c)" required></div>

            <div class="input-group mb-3">
            <input type="text" class="form-control" name="partyid" id="floatingInputValue" placeholder="PARTY ID" required><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">PARTY ID</span></div></div>
            
            SELECT FLAG TO UPLOAD ( only JPG, PNG, JPEG Format max file size 500KB)
                    <input type="file" name="fileToUpload" id="fileToUpload">

<br><br>
            <input type="reset" value="RESET" class="btn btn-warning">
            <input type="submit" value="ADD PARTY" class="btn btn-success">
            <button onclick="party()" class="btn btn-danger">CANCEL</button>
    </form>
    
    </div>`;
}

function addadmin() {
    document.getElementById("main").innerHTML=`
    <div class="shadow p-3 mb-5 bg-white rounded" style="width: 50%">
    <h5>ADD NEW ADMIN</h5>
    <form action="operation.php?k=5" method="POST" enctype="multipart/form-data">
    <div class="input-group mb-3"><div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon1">ADMIN LOGIN ID</span></div>
    <input type="text" class="form-control" name="adminid" id="floatingInputValue" placeholder="ADMIN LOGIN ID" required></div>

            <div class="input-group mb-3">
            <input type="text" class="form-control" name="adminname" id="floatingInputValue" placeholder="ADMIN NAME" required>
            <div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">ADMIN NAME</span></div></div>
            
            <div class="input-group mb-3"><div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">CONTACT</span></div>
            <input type="number" value="03" class="form-control" name="contact" id="floatingInputValue" placeholder="03XXXXXXXXX" required maxlength="11"></div>
            
            <div class="input-group mb-3">
            <input type="text" class="form-control" name="password" id="floatingInputValue" placeholder="PASSWORD" required><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">PASSWORD</span></div></div>

            <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">LEADER POSITION</span></div>
            <select class="form-select" name="role" required>
            <option selected disabled>SELECT AND ADMIN ROLE</option>
            <option value="admin">ADMIN</option>
            <option value="superadmin">SUPER ADMIN</option>
            </select>
            </div>

<br><br>
            <input type="reset" value="RESET" class="btn btn-warning">
            <input type="submit" value="ADD ADMIN" class="btn btn-success">
            <button onclick="manageadmin()" class="btn btn-danger">CANCEL</button>
    </form>
    
    </div>`;
}

function checktype(type) {
    
    if (type==0) {
        return "National Assembly";
    }
    else if (type==1) {
        return "President";
    }
    else if (type==2) {
        return "Senate";
    }
    else if (type==3) {
        return "Provincial";
    }
    else if (type==4) {
        return "District Governments";
    }
    else if (type==5) {
        return "Referendum";
    }
}

function createelection(type) {
    //document.writeln(checktype(type));
    document.getElementById("main").innerHTML = `
    <center>
    <p><i>PLEASE CLOSE/UNACTIVE ANY ACTIVE ELECTION BEFORE CREATING NEW ONE</i></p>
        <div class="shadow p-3 mb-5 bg-white rounded" style="width: 50%">
        <h5>ADD NEW ELECTION</h5>
        
        <form action="operation.php?k=3" method="POST">
        <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">ELECTION NAME</span></div>
        <input type="text" class="form-control" name="election" id="floatingInputValue" placeholder="ELECTION NAME" required></div>     
        
        <div class="input-group mb-3">
            <input type="date" class="form-control" name="startdate" id="floatingInputValue" placeholder="START DATE" required><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">START DATE</span></div></div>
        
        
            <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">START TIME</span></div>
            <input type="time" class="form-control" name="starttime" id="floatingInputValue" placeholder="START TIME" required></div>     
            
            <div class="input-group mb-3">
                <input type="date" class="form-control" name="enddate" id="floatingInputValue" placeholder="END DATE" required><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">END DATE</span></div></div>
       
                <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">END TIME</span></div>
        <input type="time" class="form-control" name="endtime" id="floatingInputValue" placeholder="END TIME" required></div>     
        
        <div class="input-group mb-3">
            <input type="text" class="form-control" name="type" id="floatingInputValue" placeholder="TYPE" value="`+checktype(type)+`" required readonly><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">TYPE</span></div></div>
        
        
            <div class="input-group mb-3"><div class="input-group-prepend"><span class="input-group-text" id="basic-addon1">LOCATION</span></div>
            <select class="form-select" name="location" id="location" required>
            <option selected disabled>SELECT A ELECTION LOCATION</option>
            <option value="Whole Pakistan">Whole Pakistan</option>
            <option value="Islamabad">Islamabad</option>
            <option value="Punjab">Punjab</option>
            <option value="Sindh">Sindh</option>
            <option value="KPK">KPK</option>
            <option value="Baluchistan">Baluchistan</option>
            <option value="Gilgit Baltistan">Gilgit Baltistan</option>
            <option value="Azad Kashmir">Azad Kashmir</option>
            <option value="Assemblies">Parliament</option>

            </select>
            </div>     
            
        <input type="reset" value="RESET" class="btn btn-warning">
        <input type="submit" value="ADD NEW ELECTION" class="btn btn-success">
        </form>
        <button onclick="election()" class="btn btn-danger">CANCEL</button>    
        </div>
      </center>
    ` ;
}

