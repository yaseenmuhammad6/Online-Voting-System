function loginform(){
    document.getElementById("header").innerHTML=`
    <div class="col-6" style="color: white;background-color:#00A651;"><center><span class="display-4">ONLINE VOTING SYSTEM</span><br>
        <h1 class="display-6">FREE &emsp; FAIR &emsp; IMPARTIAL</h1>
    </center></div>
    <div class="col-3" style="color: white;background-color:#00A651;"></div>
    <div class="col-3" style="color: white;background-color:#00A651;">
    <table>
          <form action="login.php?q=0" method="POST">
            <tr><td><br><input type="text"  placeholder="USER NAME/ID" name="uname" class="form-control form-rounded"></td></tr>
            <tr><td><br><input type="password"  placeholder="PASSWORD/PIN" name="pin" class="form-control form-rounded"></td></tr>
            <tr><td><center><br><input type="submit" value="LOGIN" class="btn btn-success"></center></td></tr>
          </form>
        </table>
    </div> `;
}
function footer() {
    document.getElementById("footer").innerHTML=`
    <div style="background-color: black;font-size: 2pt;color: black;">footer </div>
    <div class="container"><div class="row">
    <div class="col-3"></div>
    <div class="col-3"></div>
    <div class="col-3"></div>
    <div class="col-3">
    </div></div><div style="background-color: black;"><hr>
    <center><div >ONLINE VOTING SYSTEM © - 2021</center><br></div>`;
}
function info() {
    document.getElementById("info").innerHTML=`<h1 style="color:#00A651;">CREATED BY</h1>
    <center>
          <div class="container-fluid">
            <div class="row" id="CreatedBy">
                <div class="col-12">
                  <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="Images/man2.png" alt="Card image cap">
                    <div class="card-body"><h5>SAFEER</h5>
                      <p class="card-text"><i>MSC FINAL {DETAILS HERE e.g ROLL NUM e.tc}</i></p>
                    </div>
                  </div>
              </div>
              </div><br>
              <div class="row" id="CreatedBy">
                <div class="col-12">
                  <div class="card" style="width: 18rem;">
                    <img class="card-img-top" src="Images/man.png" alt="Card image cap">
                    <div class="card-body"><h5>FAWAD</h5>
                      <p class="card-text"><i>MSC FINAL {DETAILS HERE e.g ROLL NUM e.tc}</i></p>
                    </div>
                  </div>
                </div>
            </div>
        </div></center>`;
}
function about() {
    document.getElementById("About").innerHTML=`<h1 style="color:#00A651;">ABOUT</h1><p><span style="font-size: 72pt;color:#00A651;">I</span>n the new era of advanced technology where online system boosts work speed,
    reduces mistakes and promote the generation of accurate results, having manual
    election system becomes a misfortune. A public election system constitutes the
    backbone of a democracy where the people has to elect their state’s leader. Pakistan
    currently uses a manual election system, which causes several kinds of problems. Due
    to this paper ballot based election system, some problems are faced by voters before
    or during elections and others are faced by the administration before and after the
    voting. An online system, which involves procedures like registration of voters, vote
    casting, vote counting, and declaring results etc. would constitute a good solution to
    replace current system.</p>
<p>The system proposed will be helpful for the
    voters by using any resources like their own system or arranged by Government.
    Moreover, the proposed system will also decrease the risk for corruption.</p>
    <p>
        NADRA has an online database of the citizens of Pakistan, and is
        providing the Computerized National Identity Cards (CNIC) and also supporting
        different organizations with their online system. So, by using NADRA’s system it
        becomes easy to register all voters of the age 18 or above, and furthermore to verifiy
        their data
    </p>
    <p>
        An online election system will
        be best system to replace the current electoral system, and we have
        proposed the basic structure and functionality for such a system.
    </p>
    <img src="Images/ovsusecase.png">`;
}
